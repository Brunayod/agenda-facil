import 'dart:convert';

import 'package:flutter/foundation.dart';

import '../models/agendamento.dart';
import '../models/unidade.dart';
import 'armazenamento.dart';
import 'catalogo.dart';

/// Repositório (singleton) dos agendamentos do paciente com sessão ativa.
///
/// É um [ChangeNotifier]: telas com `ListenableBuilder` são reconstruídas ao
/// adicionar, cancelar ou reagendar. Cada alteração é aplicada em memória e
/// depois gravada no [Armazenamento] como JSON.
class AgendamentoRepository extends ChangeNotifier {
  AgendamentoRepository._();

  static final AgendamentoRepository instance = AgendamentoRepository._();

  Armazenamento? _armazenamento;
  String? _cpf;
  final List<Agendamento> _itens = [];
  int _sequencia = 1000;

  /// Define onde os dados são gravados (chamado uma vez no `main`).
  void configurar(Armazenamento armazenamento) {
    _armazenamento = armazenamento;
  }

  /// Carrega os agendamentos de [cpf]. Sem dados salvos, a lista fica vazia.
  Future<void> carregar(String cpf) async {
    _cpf = cpf;
    _itens.clear();

    final bruto =
        await _armazenamento?.ler(ChavesArmazenamento.agendamentos(cpf));
    if (bruto != null) {
      try {
        final lista = jsonDecode(bruto) as List;
        _itens.addAll(
          lista.map((e) => Agendamento.fromJson(e as Map<String, dynamic>)),
        );
      } catch (erro) {
        debugPrint('AgendamentoRepository: dados inválidos ($erro)');
        _itens.clear();
      }
    }

    _sequencia = _proximaSequencia();
    notifyListeners();
  }

  /// Agendamentos confirmados, do mais próximo para o mais distante.
  List<Agendamento> get ativos {
    final lista = _itens.where((a) => a.estaAtivo).toList()
      ..sort((a, b) => a.dataHora.compareTo(b.dataHora));
    return List.unmodifiable(lista);
  }

  /// Realizados, cancelados e faltas, do mais recente para o mais antigo.
  List<Agendamento> get historico {
    final lista = _itens.where((a) => !a.estaAtivo).toList()
      ..sort((a, b) => b.dataHora.compareTo(a.dataHora));
    return List.unmodifiable(lista);
  }

  Agendamento? porProtocolo(String protocolo) {
    for (final item in _itens) {
      if (item.protocolo == protocolo) return item;
    }
    return null;
  }

  /// Um horário está livre se for futuro e o usuário não tiver outro
  /// agendamento ativo exatamente na mesma data e hora.
  bool horarioDisponivel(DateTime dataHora, {String? ignorarProtocolo}) {
    if (!dataHora.isAfter(DateTime.now())) return false;
    return !_itens.any(
      (a) =>
          a.estaAtivo &&
          a.protocolo != ignorarProtocolo &&
          a.dataHora == dataHora,
    );
  }

  Future<Agendamento> adicionar({
    required TipoAtendimento tipo,
    required String servico,
    required Unidade unidade,
    required DateTime dataHora,
  }) async {
    final numero = (_sequencia++).toString().padLeft(6, '0');
    final novo = Agendamento(
      protocolo: 'AF-${DateTime.now().year}-$numero',
      tipo: tipo,
      servico: servico,
      unidade: unidade,
      profissional: Catalogo.profissionalPara(tipo, servico, unidade: unidade),
      dataHora: dataHora,
      status: StatusAgendamento.confirmado,
      orientacoes: Catalogo.orientacoesPara(tipo, servico),
    );
    _itens.add(novo);
    notifyListeners();
    await _salvar();
    return novo;
  }

  /// Move o agendamento para o histórico com status "Cancelado".
  Future<void> cancelar(String protocolo) {
    return _substituir(
      protocolo,
      (a) => a.copyWith(status: StatusAgendamento.cancelado),
    );
  }

  Future<void> reagendar(String protocolo, DateTime novaDataHora) {
    return _substituir(protocolo, (a) => a.copyWith(dataHora: novaDataHora));
  }

  Future<void> _substituir(
    String protocolo,
    Agendamento Function(Agendamento) alterar,
  ) async {
    final indice = _itens.indexWhere((a) => a.protocolo == protocolo);
    if (indice < 0) return;
    _itens[indice] = alterar(_itens[indice]);
    notifyListeners();
    await _salvar();
  }

  Future<void> _salvar() async {
    final cpf = _cpf;
    final armazenamento = _armazenamento;
    if (cpf == null || armazenamento == null) return;

    try {
      await armazenamento.gravar(
        ChavesArmazenamento.agendamentos(cpf),
        jsonEncode(_itens.map((a) => a.toJson()).toList()),
      );
    } catch (erro) {
      debugPrint('AgendamentoRepository: falha ao salvar ($erro)');
    }
  }

  /// Próximo número de protocolo, sem repetir os já existentes.
  int _proximaSequencia() {
    var maior = 999;
    for (final item in _itens) {
      final numero = int.tryParse(item.protocolo.split('-').last);
      if (numero != null && numero > maior) maior = numero;
    }
    return maior + 1;
  }
}
