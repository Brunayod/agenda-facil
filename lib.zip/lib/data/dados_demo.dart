import '../models/agendamento.dart';
import '../models/paciente.dart';
import 'catalogo.dart';

/// Dados de demonstração gravados no primeiro acesso (e usados pelo botão
/// "Acesso Rápido"). Todos os dados são fictícios.
abstract final class DadosDemo {
  static const cpf = '12345678909';
  static const cns = '700123456789010';
  static const senha = 'agenda123';

  static Paciente paciente() => Paciente(
        nome: 'Jheniffer Almeida Santos',
        cns: cns,
        cpf: cpf,
        dataNascimento: DateTime(1998, 5, 14),
        tipoSanguineo: 'O+',
        telefone: '(11) 98765-4321',
        email: 'jheniffer.santos@email.com',
        endereco: 'Rua das Flores, 120 - Vila Mariana, São Paulo - SP',
        unidadeReferenciaId: 'vila-mariana',
        alergias: const ['Dipirona'],
        condicoes: const ['Rinite'],
      );

  /// Agendamentos relativos à data atual, para o app nunca abrir vazio.
  static List<Agendamento> agendamentos() {
    final unidade = Catalogo.unidades[0];
    final ano = DateTime.now().year;
    var numero = 1000;

    Agendamento criar(
      TipoAtendimento tipo,
      String servico,
      DateTime dataHora,
      StatusAgendamento status,
    ) {
      numero++;
      return Agendamento(
        protocolo: 'AF-$ano-${numero.toString().padLeft(6, '0')}',
        tipo: tipo,
        servico: servico,
        unidade: unidade,
        profissional: Catalogo.profissionalPara(
          tipo,
          servico,
          unidade: unidade,
        ),
        dataHora: dataHora,
        status: status,
        orientacoes: Catalogo.orientacoesPara(tipo, servico),
      );
    }

    return [
      criar(
        TipoAtendimento.consulta,
        'Clínica Médica',
        _diaUtil(3, 9, 30),
        StatusAgendamento.confirmado,
      ),
      criar(
        TipoAtendimento.vacinacao,
        'Vacina da gripe',
        _diaUtil(7, 11, 0),
        StatusAgendamento.confirmado,
      ),
      criar(
        TipoAtendimento.exame,
        'Hemograma completo',
        _diaUtil(12, 8, 0),
        StatusAgendamento.confirmado,
      ),
      criar(
        TipoAtendimento.consulta,
        'Clínica Médica',
        _diaUtil(-14, 11, 0),
        StatusAgendamento.realizado,
      ),
      criar(
        TipoAtendimento.vacinacao,
        'Vacina da gripe',
        _diaUtil(-40, 15, 30),
        StatusAgendamento.realizado,
      ),
      criar(
        TipoAtendimento.exame,
        'Glicemia em jejum',
        _diaUtil(-22, 8, 0),
        StatusAgendamento.naoCompareceu,
      ),
    ];
  }

  /// Data daqui a [dias] dias, empurrada para segunda se cair no fim de semana.
  static DateTime _diaUtil(int dias, int hora, int minuto) {
    final base = DateTime.now().add(Duration(days: dias));
    var dia = DateTime(base.year, base.month, base.day, hora, minuto);
    while (dia.weekday == DateTime.saturday || dia.weekday == DateTime.sunday) {
      dia = DateTime(dia.year, dia.month, dia.day + 1, hora, minuto);
    }
    return dia;
  }
}
