import 'dart:convert';

import 'package:flutter/foundation.dart';

import '../models/paciente.dart';
import 'armazenamento.dart';

/// Repositório (singleton) dos dados do paciente com sessão ativa.
///
/// É um [ChangeNotifier]: as telas reagem com `ListenableBuilder`. Cada
/// alteração é aplicada em memória (a interface atualiza na hora) e depois
/// gravada no [Armazenamento] como JSON.
class PacienteRepository extends ChangeNotifier {
  PacienteRepository._();

  static final PacienteRepository instance = PacienteRepository._();

  Armazenamento? _armazenamento;
  Paciente? _paciente;

  /// Define onde os dados são gravados (chamado uma vez no `main`).
  void configurar(Armazenamento armazenamento) {
    _armazenamento = armazenamento;
  }

  bool get temPaciente => _paciente != null;

  /// Paciente com sessão ativa. Só use depois do login.
  Paciente get paciente {
    final atual = _paciente;
    if (atual == null) {
      throw StateError('Nenhum paciente carregado. Faça login primeiro.');
    }
    return atual;
  }

  /// Carrega o paciente de [cpf]. Devolve `false` se não houver dados válidos.
  Future<bool> carregar(String cpf) async {
    final bruto = await _armazenamento?.ler(ChavesArmazenamento.paciente(cpf));
    if (bruto == null) return false;

    try {
      _paciente = Paciente.fromJson(jsonDecode(bruto) as Map<String, dynamic>);
      notifyListeners();
      return true;
    } catch (erro) {
      debugPrint('PacienteRepository: dados inválidos para $cpf ($erro)');
      return false;
    }
  }

  /// Substitui os dados cadastrais (formulário "Editar dados").
  Future<void> atualizar(Paciente novo) async {
    _paciente = novo;
    notifyListeners();
    await _salvar();
  }

  // ----- Alergias e condições -----

  /// Devolve `false` se o texto for vazio ou já existir na lista.
  Future<bool> adicionarAlergia(String item) async {
    final texto = item.trim();
    if (texto.isEmpty || _contem(paciente.alergias, texto)) return false;
    await atualizar(paciente.copyWith(alergias: [...paciente.alergias, texto]));
    return true;
  }

  Future<void> removerAlergia(String item) => atualizar(
        paciente.copyWith(
          alergias: paciente.alergias.where((a) => a != item).toList(),
        ),
      );

  /// Devolve `false` se o texto for vazio ou já existir na lista.
  Future<bool> adicionarCondicao(String item) async {
    final texto = item.trim();
    if (texto.isEmpty || _contem(paciente.condicoes, texto)) return false;
    await atualizar(
      paciente.copyWith(condicoes: [...paciente.condicoes, texto]),
    );
    return true;
  }

  Future<void> removerCondicao(String item) => atualizar(
        paciente.copyWith(
          condicoes: paciente.condicoes.where((c) => c != item).toList(),
        ),
      );

  // ----- Preferências -----

  Future<void> definirLembretes(bool ativos) =>
      atualizar(paciente.copyWith(lembretesAtivos: ativos));

  Future<void> definirTamanhoTexto(TamanhoTexto tamanho) =>
      atualizar(paciente.copyWith(tamanhoTexto: tamanho));

  Future<void> _salvar() async {
    final atual = _paciente;
    final armazenamento = _armazenamento;
    if (atual == null || armazenamento == null) return;

    try {
      await armazenamento.gravar(
        ChavesArmazenamento.paciente(atual.cpf),
        jsonEncode(atual.toJson()),
      );
    } catch (erro) {
      debugPrint('PacienteRepository: falha ao salvar ($erro)');
    }
  }

  static bool _contem(List<String> lista, String texto) {
    final alvo = texto.toLowerCase();
    return lista.any((item) => item.toLowerCase() == alvo);
  }
}
