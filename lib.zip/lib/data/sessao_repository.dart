import 'dart:convert';

import 'package:flutter/foundation.dart';

import '../models/credencial.dart';
import '../models/paciente.dart';
import 'agendamento_repository.dart';
import 'armazenamento.dart';
import 'dados_demo.dart';
import 'paciente_repository.dart';

/// Repositório (singleton) de contas e sessão.
///
/// Guarda as credenciais cadastradas no dispositivo e qual conta está
/// logada. Ao entrar, carrega o paciente e os agendamentos da conta.
/// Os métodos que podem falhar devolvem uma mensagem de erro (ou `null`).
class SessaoRepository extends ChangeNotifier {
  SessaoRepository._();

  static final SessaoRepository instance = SessaoRepository._();

  Armazenamento? _armazenamento;
  final List<Credencial> _contas = [];
  String? _cpfAtivo;

  bool get logado => _cpfAtivo != null;

  /// CPF (só dígitos) da conta logada.
  String? get cpfAtivo => _cpfAtivo;

  /// Carrega as contas e restaura a sessão salva. No primeiro acesso (sem
  /// nenhum dado) grava a conta e os dados de demonstração.
  Future<void> inicializar(Armazenamento armazenamento) async {
    _armazenamento = armazenamento;
    await _carregarContas();

    final cpfSalvo = await armazenamento.ler(ChavesArmazenamento.sessao);
    if (cpfSalvo == null) return;

    final existe = _contas.any((c) => c.cpf == cpfSalvo);
    final ativou = existe && await _ativar(cpfSalvo);
    if (!ativou) await armazenamento.remover(ChavesArmazenamento.sessao);
  }

  /// Entra com CPF (11 dígitos) ou CNS (15 dígitos) e senha.
  Future<String?> entrar({
    required String identificador,
    required String senha,
  }) async {
    final digitos = identificador.replaceAll(RegExp(r'\D'), '');
    final conta = _contas
        .where((c) => c.cpf == digitos || c.cns == digitos)
        .firstOrNull;

    if (conta == null || !conta.confere(senha)) {
      return 'CPF/CNS ou senha incorretos.';
    }
    final ok = await _ativar(conta.cpf);
    return ok ? null : 'Não foi possível carregar seus dados. Tente novamente.';
  }

  /// Cria a conta de um novo paciente e já entra com ela.
  Future<String?> cadastrar({
    required Paciente paciente,
    required String senha,
  }) async {
    if (_contas.any((c) => c.cpf == paciente.cpf)) {
      return 'Já existe uma conta com este CPF.';
    }
    if (_contas.any((c) => c.cns == paciente.cns)) {
      return 'Já existe uma conta com este CNS.';
    }

    final armazenamento = _armazenamento;
    if (armazenamento == null) return 'Armazenamento indisponível.';

    _contas.add(
      Credencial.nova(cpf: paciente.cpf, cns: paciente.cns, senha: senha),
    );
    await _gravarContas();
    await armazenamento.gravar(
      ChavesArmazenamento.paciente(paciente.cpf),
      jsonEncode(paciente.toJson()),
    );

    final ok = await _ativar(paciente.cpf);
    return ok ? null : 'Não foi possível concluir o cadastro.';
  }

  /// Entra direto com a paciente de demonstração (recria os dados se faltarem).
  Future<void> entrarComoDemo() async {
    await _garantirDemo();
    await _ativar(DadosDemo.cpf);
  }

  /// Encerra a sessão. Os dados continuam salvos no dispositivo.
  Future<void> sair() async {
    _cpfAtivo = null;
    notifyListeners();
    await _armazenamento?.remover(ChavesArmazenamento.sessao);
  }

  Future<bool> _ativar(String cpf) async {
    final armazenamento = _armazenamento;
    if (armazenamento == null) return false;

    final carregou = await PacienteRepository.instance.carregar(cpf);
    if (!carregou) return false;
    await AgendamentoRepository.instance.carregar(cpf);

    await armazenamento.gravar(ChavesArmazenamento.sessao, cpf);
    _cpfAtivo = cpf;
    notifyListeners();
    return true;
  }

  Future<void> _carregarContas() async {
    final bruto = await _armazenamento?.ler(ChavesArmazenamento.contas);
    _contas.clear();

    if (bruto != null) {
      try {
        final lista = jsonDecode(bruto) as List;
        _contas.addAll(
          lista.map((e) => Credencial.fromJson(e as Map<String, dynamic>)),
        );
        return;
      } catch (erro) {
        debugPrint('SessaoRepository: contas inválidas ($erro)');
        _contas.clear();
      }
    }

    // Primeiro acesso (ou dados corrompidos): grava a demonstração.
    await _garantirDemo();
  }

  Future<void> _garantirDemo() async {
    final armazenamento = _armazenamento;
    if (armazenamento == null) return;

    final temConta = _contas.any((c) => c.cpf == DadosDemo.cpf);
    final temDados = await armazenamento
            .ler(ChavesArmazenamento.paciente(DadosDemo.cpf)) !=
        null;
    if (temConta && temDados) return;

    _contas.removeWhere((c) => c.cpf == DadosDemo.cpf);
    _contas.add(
      Credencial.nova(
        cpf: DadosDemo.cpf,
        cns: DadosDemo.cns,
        senha: DadosDemo.senha,
      ),
    );
    await _gravarContas();
    await armazenamento.gravar(
      ChavesArmazenamento.paciente(DadosDemo.cpf),
      jsonEncode(DadosDemo.paciente().toJson()),
    );
    await armazenamento.gravar(
      ChavesArmazenamento.agendamentos(DadosDemo.cpf),
      jsonEncode(DadosDemo.agendamentos().map((a) => a.toJson()).toList()),
    );
  }

  Future<void> _gravarContas() async {
    await _armazenamento?.gravar(
      ChavesArmazenamento.contas,
      jsonEncode(_contas.map((c) => c.toJson()).toList()),
    );
  }
}
