import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'core/app_theme.dart';
import 'data/agendamento_repository.dart';
import 'data/armazenamento.dart';
import 'data/paciente_repository.dart';
import 'data/sessao_repository.dart';
import 'screens/app_raiz.dart';

import 'package:supabase_flutter/supabase_flutter.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
    url: 'https://qnmbyqbpssbndxrmdwxx.supabase.co',
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFubWJ5cWJwc3NibmR4cm1kd3h4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTM4NjgwMDMsImV4cCI6MjEwOTQ0NDAwM30.UuyBkkDb-5IANRjPJe_FFviY3g45TtQYIXjn6h7jfvY',
  );
  runApp(const MyApp());
}
final supabase = Supabase.instance.client;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light, // Android
      statusBarBrightness: Brightness.dark, // iOS
    ),
  );

  // Armazenamento local (shared_preferences). Para sincronizar com a nuvem,
  // troque esta implementação ou crie repositórios remotos.
  final armazenamento = await ArmazenamentoLocal.criar();
  PacienteRepository.instance.configurar(armazenamento);
  AgendamentoRepository.instance.configurar(armazenamento);

  // Restaura a sessão salva; no primeiro acesso grava os dados de demonstração.
  await SessaoRepository.instance.inicializar(armazenamento);

  runApp(const AgendaFacilApp());
}

class AgendaFacilApp extends StatelessWidget {
  const AgendaFacilApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Agenda Fácil',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      // Aplica a preferência "Tamanho do texto" do perfil em todo o app,
      // somada à escala de fonte do sistema (só com sessão ativa).
      builder: (context, child) {
        return ListenableBuilder(
          listenable: Listenable.merge([
            SessaoRepository.instance,
            PacienteRepository.instance,
          ]),
          builder: (context, _) {
            final sessao = SessaoRepository.instance;
            final pacientes = PacienteRepository.instance;
            final fator = sessao.logado && pacientes.temPaciente
                ? pacientes.paciente.tamanhoTexto.fator
                : 1.0;

            final media = MediaQuery.of(context);
            return MediaQuery(
              data: media.copyWith(
                textScaler: TextScaler.linear(media.textScaler.scale(1) * fator),
              ),
              child: child ?? const SizedBox.shrink(),
            );
          },
        );
      },
      home: const AppRaiz(),
    );
  }
}
